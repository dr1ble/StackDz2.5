import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Deque d = new Deque();
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите количество элементов в дэки");
        Integer n = sc.nextInt();
        try {
            for(int i = 0; i < n; i++)
                d.pushFront((int)(Math.random()*10));
            System.out.println("Элементы в прямом порядке: ");
            for (int i = 0; i < n; i++) {
                int b = d.popBack();
                System.out.println(b);
                d.pushFront(b);
            }
            System.out.println("Элементы в обратном порядке: ");
            for (int i = 0; i < n; i++) {
                int b = d.popFront();
                System.out.println(b);
                d.pushBack(b);
            }
        }
        catch (Exception e) {
        }
    }
}
